<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\User;
use App\Models\product;
use App\Models\basket;



class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        
        User::insert([
            'login' => 'sklad ',
            'email' => 'sklad@mail.ru',
            'phonenumber' => '+7 (953) 602-39-92',
            'FIO' => 'Склад Склад Склад',
            'password' => bcrypt('123qwe'),
        ]);
        User::insert([
            'login' => 'lomov',
            'email' => 'lomov2006@mail.ru',
            'phonenumber' => '+7 (953) 602-39-91',
            'FIO' => 'Ломов Михаил Сергеевич',
            'password' => bcrypt('123456'),
        ]);
        basket::insert([
            [
                'id_user' => 1,
            ],
            [
                'id_user' => 2,
            ],
        ]);
        product::insert([
            [
                'name' => 'Набор блюд',
                'count' => 20,
                'cost' => 1900,
                'image' => '1.jpg',
            ],
            [
                'name' => 'Базовые продукты',
                'count' => 14,
                'cost' => 890,
                'image' => '2.png',
            ],
            [
                'name' => 'Молочные продукты',
                'count' => 10,
                'cost' => 790,
                'image' => '3.jfif',
            ],
            [
                'name' => 'Хлеб',
                'count' => 20,
                'cost' => 190,
                'image' => '4.jpg',
            ],
            [
                'name' => 'Набор продуктов',
                'count' => 0,
                'cost' => 1790,
                'image' => '5.jpg',
            ]
        ]);
    }
}
