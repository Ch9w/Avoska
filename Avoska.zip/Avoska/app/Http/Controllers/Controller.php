<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use App\Models\User;
use App\Models\product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\basket;
use App\Models\basket_product;



class Controller extends BaseController
{
    use AuthorizesRequests, ValidatesRequests;
    function main()
    {
        $users = User::get();
        $adminuser = User::where('login', 'sklad')->first();
        if (Auth::id() == $adminuser->id) {
            return redirect()->route('admin');
        }
        return view('main', ['users' => $users]);
    }
    function admin(Request $request)
    {
        $users = User::get();
        $adminuser = User::where('login', 'sklad')->first();
        if (Auth::id() == $adminuser->id) {
            if ($request->method() == 'GET') {
                return view('admin', ['users' => $users]);
            }
            if ($request->method() == 'POST') {
                return redirect()->route('admin');
            }
        } else {
            return redirect()->route('main');
        }
    }

    function authorization(Request $request)
    {
        if (Auth::check()) {
            return redirect()->route('main');
        }
        if ($request->method() == 'GET') {
            return view('authorization');
        }
        if ($request->method() == 'POST') {
            if ($request->login == null) {
                return view('authorization')->withErrors(['error' => 'Введите логин']);
            }
            if ($request->password == null) {
                return view('authorization')->withErrors(['error' => 'Введите пароль']);
            }
            $login = $request->login;
            $password = $request->password;
            $credentials = $request->validate([
                'login' => 'required',
                'password' => 'required'
            ]);
            if (Auth::attempt($credentials)) {
                return redirect()->route('main');
            } else {
                return view('authorization')->withErrors(['error' => 'Логин или пароль не совпадает']);
            }
            return redirect()->route('main');
        }
    }

    function registration(Request $request)
    {
        if (Auth::check()) {
            return redirect()->route('main');
        }
        if ($request->method() == 'GET') {
            return view('registration');
        }
        if ($request->method() == 'POST') {
            if (
                $request->login == null ||
                $request->email == null ||
                $request->phonenumber == null ||
                $request->FIO == null ||
                $request->password == null ||
                $request->repeatpassword == null
            ) {
                return view('registration')->withErrors(['error' => 'Заполните все поля']);
            }
            if (strlen($request->login) < 4) {
                return view('registration')->withErrors(['error' => 'Логин должен быть минимум 4 символа']);
            }
            $arrFIO = explode(" ", $request->FIO);
            if (count($arrFIO) != 3) {
                return view('registration')->withErrors(['error' => 'Введите Фамилию Имя Отчество через пробел']);
            }
            if (strlen($request->password) < 6) {
                return view('registration')->withErrors(['error' => 'Пароль должен быть минимум 6 символов']);
            }
            if ($request->password != $request->repeatpassword) {
                return view('registration')->withErrors(['error' => 'Пароли должны совпадать']);
            }

            if (User::where('login', $request->login)->first()) {
                return view('registration')->withErrors(['error' => 'Пользователь с таким логином уже зарегистрирован']);
            }
            if (User::where('login', $request->email)->first()) {
                return view('registration')->withErrors(['error' => 'Пользователь с таким email уже зарегистрирован']);
            }
            if (User::where('login', $request->phonenumber)->first()) {
                return view('registration')->withErrors(['error' => 'Пользователь с таким номером телефона уже зарегистрирован']);
            }
            $newuser = new User();
            $newuser->login = $request->login;
            $newuser->email = $request->email;
            $newuser->phonenumber = $request->phonenumber;
            $newuser->FIO = $request->FIO;
            $newuser->password = $request->password;
            $newuser->save();
            $user = User::where('login', $request->login)->first();
            $newbasket = new basket();
            $newbasket->id_user = $user->id;
            $newbasket->save();
            Auth::login($user);
            return redirect()->route('main');
        }
    }
    function catalog(Request $request)
    {
        $isadmin = false;
        $users = User::get();
        $adminuser = User::where('login', 'sklad')->first();
        $products = product::where('count', '>', 0);

        if ($request->method() == 'GET') {
            if (Auth::id() == $adminuser->id) {
                $isadmin = true;
                $products = product::all();
                return view('catalog', ['products' => $products, 'isadmin' => $isadmin]);
            } else {
            }
            return view('catalog', ['products' => $products->get(), 'isadmin' => $isadmin]);
        }
        if ($request->method() == 'POST') {
            if (Auth::id() == $adminuser->id) {
                $isadmin = true;
                if ($request->type == "Удалить") {
                    product::where('id', $request->idproduct)->delete();
                }
            } else {
            }
            if (!empty($request->poisk)) {
                $products = $products->where('name', 'like', '%' . $request->input('poisk') . '%');
            }
            return view('catalog', ['products' => $products->get(), 'isadmin' => $isadmin]);
        }
    }
    function redproduct(Request $request)
    {
        $users = User::get();
        $adminuser = User::where('login', 'sklad')->first();
        $product = product::where('id', $request->idproduct);
        if (Auth::id() == $adminuser->id) {
            if ($request->method() == 'GET') {
                return view('redproduct', ['product' => $product->first()]);
            }
            if ($request->method() == 'POST') {
                $product = $product->first();
                $request->validate([
                    'name' => 'required',
                    'cost' => 'required',
                    'count' => 'required',
                ]);
                $product->name = $request->name;
                $product->cost = $request->cost;
                $product->count = $request->count;
                if (isset($request->image)) {
                    $fn = null;
                    $fileName = null;
                    $file = $request->file('image');
                    $fileName = time() . $file->getClientOriginalName();
                    $file->move(public_path('images'), $fileName);
                    $product->image = $fileName;
                }
                $product->save();
                return view('redproduct', ['product' => $product])->withErrors(['error' => 'Вы изменили товар']);
            }
        } else {
            return redirect()->route('catalog');
        }
    }
    function addproduct(Request $request)
    {
        $users = User::get();
        $adminuser = User::where('login', 'sklad')->first();
        if (Auth::id() == $adminuser->id) {
            if ($request->method() == 'GET') {
                return view('addproduct');
            }
            if ($request->method() == 'POST') {
                $newproduct = new product();
                $request->validate([
                    'name' => 'required',
                    'cost' => 'required',
                    'count' => 'required',
                    'image' => 'required'
                ]);
                $newproduct->name = $request->name;
                $newproduct->cost = $request->cost;
                $newproduct->count = $request->count;
                $fn = null;
                $fileName = null;
                $file = $request->file('image');
                $fileName = time() . $file->getClientOriginalName();
                $file->move(public_path('images'), $fileName);
                $newproduct->image = $fileName;
                $newproduct->save();
                return view('addproduct')->withErrors(['error' => 'Вы добавили товар']);
            }
        } else {
            return redirect()->route('catalog');
        }
    }


    function product($id, Request $request)
    {
        if ($request->method() == 'GET') {
            $product = product::find($id);
            return view('product', ['product' => $product]);
        }
        if ($request->method() == 'POST') {
            $product = product::find($id);

            if (product::find($id)->count == 0) {
                return view('product', ['product' => $product])->withErrors(['error' => 'Товар закончился на складе']);
            }
            if (product::find($id)->count < $request->count) {
                return view('product', ['product' => $product])->withErrors(['error' => 'На складе не хватает товара, выберите меньше']);
            }
            $mybusket = basket::where('id_user', Auth::id())->where('status', null)->first();
            if (basket_product::where('id_basket', $mybusket->id)->where('id_product', $id)->first() != null) {
                return view('product', ['product' => $product])->withErrors(['error' => 'Этот товар есть в вашей корзине']);
            }
            $newbasket_product = new basket_product();
            $id_basket = basket::where('id_user', Auth::id())->where('status', null)->first();
            $newbasket_product->id_basket = $id_basket->id;
            $newbasket_product->id_product = $id;
            $newbasket_product->count = $request->count;
            $newbasket_product->save();
            return view('product', ['product' => $product])->withErrors(['error' => 'Товар добавлен в вашу корзину']);
        }
        return redirect()->route('main');
    }
    function adminbasket(Request $request)
    {
        $users = User::all();
        $adminuser = User::where('login', 'sklad')->first();
        $product = product::where('id', $request->idproduct);
        if (Auth::id() == $adminuser->id) {
            $basket_products = basket_product::all();
            $baskets = basket::where('status', 'новое')->get();

            $products = product::get();

            if ($request->method() == 'GET') {
                return view('adminbasket', ['basket_products' => $basket_products, 'products' => $products, 'baskets' => $baskets, 'users' => $users]);
            }
            if ($request->method() == 'POST') {
                $thisbasket = basket::where('id', $request->thisbasket)->first();
                $thisbasket->status = $request->status;
                $thisbasket->save();
                return redirect()->route('adminbasket');
            }
        } else {
            return redirect()->route('basket');
        }
    }
    function basket(Request $request)
    {
        if ($request->method() == 'GET') {
            $baskets = basket::where('id_user', Auth::id())->where('status', '!=', null)->get();
            $basket = basket::where('id_user', Auth::id())->where('status', null)->first();
            $basket_products = basket_product::where('id_basket', $basket->id)->get();
            $products = product::get();
            $basket_products2 = basket_product::all();

            return view('basket', ['basket_products2' => $basket_products2, 'basket_products' => $basket_products, 'products' => $products, 'idbasket' => $basket->id, 'baskets' => $baskets]);
        }
        if ($request->method() == 'POST') {
            if ($request->type == "Поиск") {
                $baskets = basket::where('id_user', Auth::id())->where('status', $request->status)->get();
                $basket = basket::where('id_user', Auth::id())->where('status', null)->first();
                $basket_products = basket_product::where('id_basket', $basket->id)->get();
                $products = product::get();
                $basket_products2 = basket_product::all();
                return view('basket', ['basket_products2' => $basket_products2, 'basket_products' => $basket_products, 'products' => $products, 'idbasket' => $basket->id, 'baskets' => $baskets]);
            }

            if ($request->type == "Изменить") {
                $products = product::get();
                $basket = basket::where('id_user', Auth::id())->where('status', null)->first();
                $basket_products = basket_product::where('id_basket', $basket->id)->get();
                if (product::find(basket_product::where('id', $request->idproduct)->first()->id_product)->count == 0) {
                    return redirect()->route('basket')->withErrors(['error' => 'Товар закончился на складе']);
                }
                if (product::find(basket_product::where('id', $request->idproduct)->first()->id_product)->count < $request->thiscount) {
                    return redirect()->route('basket')->withErrors(['error' => 'На складе не хватает товара, выберите меньше']);
                } else {
                    $thisproduct = basket_product::where('id', $request->idproduct)->first();
                    $thisproduct->count = $request->thiscount;
                    $thisproduct->save();
                }
            }
            if ($request->type == "Удалить") {
                $basket = basket::where('id_user', Auth::id())->where('status', null)->first();
                basket_product::where('id', $request->idproduct)->delete();
            }
            if ($request->type == "Заказать") {
                $basket = basket::where('id_user', Auth::id())->where('status', null)->first();
                $basket_products = basket_product::where('id_basket', $basket->id)->get();
                $products = product::get();

                if (count($basket_products) == 0) {
                    return redirect()->route('basket')->withErrors(['error' => 'Выберите товары']);
                }
                if ($request->address == null) {
                    $basket = basket::where('id_user', Auth::id())->where('status', null)->first();
                    $basket_products = basket_product::where('id_basket', $basket->id)->get();
                    $products = product::get();
                    return redirect()->route('basket')->withErrors(['error1' => 'Введите адрес']);
                }
                $basket = basket::where('id_user', Auth::id())->where('status', null)->first();

                $basket_products = basket_product::where('id_basket', $basket->id)->get();
                $products = product::get();

                foreach ($basket_products as $basket_product) {
                    if (product::where('id', $basket_product->id_product)->first()->count < $basket_product->count) {
                        return redirect()->route('basket')->withErrors(['error1' => 'Товар ' . product::where('id', $basket_product->id_product)->first()->name . ' закончился на складе']);
                    }
                }
                foreach ($basket_products as $basket_product) {
                    $thisproduct = product::where('id', $basket_product->id_product)->first();
                    $thisproduct->count = product::where('id', $basket_product->id_product)->first()->count - $basket_product->count;
                    $thisproduct->save();
                }

                $thisbasket = basket::where('id_user', Auth::id())->where('status', null)->first();
                $thisbasket->status = 'новое';
                $thisbasket->address = $request->address;
                $thisbasket->save();
                $newbasket = new basket();
                $newbasket->id_user = Auth::id();
                $newbasket->save();
            }
            $products = product::get();
            $basket = basket::where('id_user', Auth::id())->where('status', null)->first();
            $basket_products = basket_product::where('id_basket', $basket->id)->get();
            return redirect()->route('basket');
        }
        return redirect()->route('main');
    }
}
