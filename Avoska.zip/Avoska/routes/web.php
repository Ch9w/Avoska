<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', [Controller::class, 'registration']);
Route::get('/registration', [Controller::class, 'registration'])->name('registration');
Route::post('/registration', [Controller::class, 'registration']);

Route::get('/authorization', [Controller::class, 'authorization'])->name('authorization');
Route::post('/authorization', [Controller::class, 'authorization']);


Route::middleware(['auth'])->group(function () {
    Route::get('/catalog', [Controller::class, 'catalog'])->name('catalog');
    Route::post('/catalog', [Controller::class, 'catalog']);

    Route::get('/product/{id}', [Controller::class, 'product'])->name('product');
    Route::post('/product/{id}', [Controller::class, 'product']);

    Route::get('/redproduct', [Controller::class, 'redproduct'])->name('redproduct');
    Route::post('/redproduct', [Controller::class, 'redproduct']);

    Route::get('/addproduct', [Controller::class, 'addproduct'])->name('addproduct');
    Route::post('/addproduct', [Controller::class, 'addproduct']);

    Route::get('/admin', [Controller::class, 'admin'])->name('admin');
    Route::post('/admin', [Controller::class, 'admin']);

    Route::get('/main', [Controller::class, 'main'])->name('main');


    Route::get('/logout', function () {
        Auth::logout();
        return redirect()->route('authorization');
    })->name('logout');
    Route::get('/main', [Controller::class, 'main'])->name('main');

    Route::get('/basket', [Controller::class, 'basket'])->name('basket');
    Route::post('/basket', [Controller::class, 'basket']);

    Route::get('/adminbasket', [Controller::class, 'adminbasket'])->name('adminbasket');
    Route::post('/adminbasket', [Controller::class, 'adminbasket']);

});
