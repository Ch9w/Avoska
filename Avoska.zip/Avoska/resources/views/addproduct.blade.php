<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel='stylesheet' href="{{ asset('css/head.css') }}" />
    <link rel='stylesheet' href="{{ asset('css/main.css') }}" />
    <link rel='stylesheet' href="{{ asset('css/footer.css') }}" />
    <link rel='stylesheet' href="{{ asset('bootstrap/css/bootstrap.min.css') }}" />
</head>

<body>
    <div>
        @include('header')
        <div class='main'>
            <div class="container">
                <h2>Добавление товара</h2>
                <form method="POST" action="addproduct" enctype="multipart/form-data">
                    @csrf
                    <table>
                        <tr>
                            <td>Название</td>
                            <td><input type="text" name="name"
                                    value="{{old('name')}}"></td>
                        </tr>
                        <tr>
                            <td>Цена</td>
                            <td><input type="number" min="1" name="cost" value="{{old('cost')}}"></td>
                        </tr>
                        <tr>
                            <td>Количество</td>
                            <td><input type="number" min="0" name="count" value="{{old('count')}}"></td>
                        </tr>
                        <tr>
                            <td>Изображение</td>
                            <td><input name="image" accept="image/png, image/jpg, image/webp" type="file"></td>
                        </tr>
                        <tr>
                            <td colspan="2">
                                @error('name')
                                    <div>Поле название обязательно</div>
                                @enderror
                                @error('cost')
                                    <div>Поле цена обязательно</div>
                                @enderror
                                @error('count')
                                    <div>Поле количество обязательно</div>
                                @enderror
                                @error('image')
                                    <div>Загрузите изображение обязательно</div>
                                @enderror
                                @error('error')
                                    <div>{{ $message }}</div>
                                @enderror
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <input type="submit" value="Добавить">
                            </td>
                        </tr>
                    </table>
                </form>
            </div>
        </div>
    </div>
    <div>
        @include('footer')
    </div>
</body>

</html>
