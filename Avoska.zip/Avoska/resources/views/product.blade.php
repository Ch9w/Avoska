<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel='stylesheet' href="{{ asset('css/head.css') }}" />
    <link rel='stylesheet' href="{{ asset('css/main.css') }}" />
    <link rel='stylesheet' href="{{ asset('css/footer.css') }}" />
    <link rel='stylesheet' href="{{ asset('bootstrap/css/bootstrap.min.css') }}" />
</head>

<body>
    <div>
        @include('header')
        <div class='main'>
            <h2 style="text-align: center;">Товар</h2>
            <div class="container">
                <h1>{{ $product->name }}</h1>
                <div class="container d-flex">
                    <div class="w-50">
                        <img src="{{ asset('images/' . $product->image) }}" class="w-100" alt="...">
                    </div>
                    <div class="w-50 cost p-4">
                        <div>Цена: {{ $product->cost }} рублей</div>
                        @if (Auth::check())
                            @if ($product->count > 0)
                                <div>
                                    <form action="{{ $product->id }}" method="POST">
                                        @csrf
                                        <div>
                                            <input type="number" min="1" value="1" name="count" value="@php if (isset($_POST['count'])) echo $_POST['count']; @endphp">
                                        </div>
                                        <br>
                                        <div>
                                            <input type="submit" class="btn btn-secondary bg-primary" value="Добавить">
                                        </div>
                                    </form>
                                </div>
                            @endif
                        @endif
                        @error('error')
                            {{ $message }}
                        @enderror
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div>
        @include('footer')
    </div>
</body>

</html>
