<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel='stylesheet' href="{{asset('css/head.css')}}"/>
    <link rel='stylesheet' href="{{asset('css/authorization.css')}}"/>
    <link rel='stylesheet' href="{{asset('css/footer.css')}}"/>

</head>
<body>
    <div>
        @include('header')
        <div class='auth'>
            <h2 style='text-align:center;'>Авторизация</h2>
            <form method='POST' action='authorization'>
                @csrf
                <table>
                    <tr>
                        <td>Логин</td>
                        <td>
                            <input type='text' name='login' placeholder='Логин' value="@php if (isset($_POST['login'])) echo $_POST['login']; @endphp">
                        </td>
                    </tr>
                    <tr>
                        <td>Пароль</td>
                        <td><input type='password' name='password' placeholder='Пароль' value="@php if (isset($_POST['password'])) echo $_POST['password']; @endphp"></td>
                    </tr>
                    <tr>
                        <td colspan='2'><a href="{{route('registration')}}">Нет аккаунта?</a></td>
                    </tr>
                    <tr>
                        <td colspan='2'><input type='submit' value='Авторизоваться'></td>
                    </tr>
                    <tr>
                        <td colspan='2'>
                            @error('error')
                                {{$message}}
                            @enderror
                        </td>
                    </tr>
                </table>
            </form>
        </div>
    </div>
    <div>
        @include('footer')
    </div>
</body>
</html>