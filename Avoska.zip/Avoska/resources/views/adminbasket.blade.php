<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel='stylesheet' href="{{ asset('css/head.css') }}" />
    <link rel='stylesheet' href="{{ asset('css/main.css') }}" />
    <link rel='stylesheet' href="{{ asset('css/footer.css') }}" />
    <link rel='stylesheet' href="{{ asset('bootstrap/css/bootstrap.min.css') }}" />
</head>

<body>
    <div>
        @include('header')
        <div class='main'>
            <div class="container">
                <h3>Заказы</h3>
                @error('error')
                    {{ $message }}
                @enderror
                @foreach ($baskets as $basket)
                    <div class="basket">
                        <div class="container container-grid">
                            @foreach ($basket_products as $basket_product)
                                @if ($basket->id == $basket_product->id_basket)
                                    <div class="col mb-4">
                                        <div class="card">
                                            <img src="{{ asset('images/' . $products->find($basket_product->id_product)->image) }}"
                                                class="card-img-top" alt="...">
                                            <div class="card-body">
                                                <h5 class="card-title">
                                                    {{ $products->find($basket_product->id_product)->name }}</h5>
                                                <p class="card-text">
                                                    {{ $products->find($basket_product->id_product)->cost }} рублей
                                                </p>
                                                <p class="card-text">Количество {{ $basket_product->count }} шт</p>
                                            </div>
                                        </div>
                                    </div>
                                @endif
                            @endforeach
                        </div>
                        <div class="container">
                            <b>ФИО: </b>{{ $users->where('id', $basket->id_user)->first()->FIO }}<br>
                            <b>Адрес: </b>{{ $basket->address }}
                            <form method="POST" action="adminbasket">
                                @csrf
                                <input name="thisbasket" value="{{ $basket->id }}" hidden>
                                <br>
                                <b>Статус: </b>
                                <select name="status" class="mb-2">
                                    <option value="новое">Новый</option>
                                    <option value="подтверждено">Подтвердить</option>
                                    <option value="отменено">Отменить</option>
                                </select>
                                <input type="submit" value="Изменить статус">
                            </form>
                        </div>
                    </div>
                    <br>
                @endforeach
            </div>
        </div>
    </div>
    <div>
        @include('footer')
    </div>
</body>

</html>
