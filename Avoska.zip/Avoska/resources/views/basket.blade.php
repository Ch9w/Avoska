<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel='stylesheet' href="{{ asset('css/head.css') }}" />
    <link rel='stylesheet' href="{{ asset('css/main.css') }}" />
    <link rel='stylesheet' href="{{ asset('css/footer.css') }}" />
    <link rel='stylesheet' href="{{ asset('bootstrap/css/bootstrap.min.css') }}" />
</head>

<body>
    <div>
        @include('header')
        <div class='main'>
            <div class="container">
                <h3 style="text-align: center">Текущая корзина</h3>
                @error('error')
                    {{ $message }}
                @enderror
                <div class="container container-grid">
                    @foreach ($basket_products as $basket_product)
                        <div class="col mb-4">
                            <div class="card">
                                <img src="{{ asset('images/' . $products->find($basket_product->id_product)->image) }}"
                                    class="card-img-top" alt="...">
                                <div class="card-body">
                                    <h5 class="card-title">{{ $products->find($basket_product->id_product)->name }}</h5>
                                    <p class="card-text">{{ $products->find($basket_product->id_product)->cost }} рублей
                                    </p>
                                    <p class="card-text">Количество {{ $basket_product->count }} шт</p>
                                    <form action="basket" method="POST">
                                        @csrf
                                        <input name="idproduct" value="{{ $basket_product->id }}" hidden>
                                        <input class="w-100" name="thiscount" type="number" min="1"
                                            value="1">
                                        <br> <br>

                                        <input name="type" type="submit" class="btn bg-warning" value="Изменить">
                                    </form>
                                    <br>
                                    <form action="basket" method="POST">
                                        @csrf
                                        <input name="idproduct" value="{{ $basket_product->id }}" hidden>
                                        <input name="type" type="submit" class="btn bg-danger" value="Удалить">
                                    </form>
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
                <div class="container">
                    <h3 style="text-align: center">Оформление заказа</h3><br>
                    @error('error1')
                        {{ $message }}
                    @enderror

                    <form class="s-20 mb-3" action="basket" method="POST">
                        @csrf
                        <div class="mb-2">Адрес: <input name="address" type="text"></div>
                        <input name="type" type="submit" value="Заказать">
                    </form>
                </div>
                <div class="container">
                    <h3 style="text-align: center">Список заказов</h3><br>
                    <form class="mb-2" method="POST" action="basket">
                        @csrf
                        <div>Поиск по статусу
                            <select name="status" class="mb-2">
                                <option value="новое">Новый</option>
                                <option value="подтверждено">Подтвердённый</option>
                                <option value="отменено">Отменённый</option>
                            </select>
                        </div>
                        <input name="type" type="submit" value="Поиск">
                    </form>
                    @foreach ($baskets as $basket)
                        <div class="basket">
                            <div class="container container-grid">
                                @foreach ($basket_products2 as $basket_product)
                                    @if ($basket->id == $basket_product->id_basket)
                                        <div class="col mb-4">
                                            <div class="card">
                                                <img src="{{ asset('images/' . $products->find($basket_product->id_product)->image) }}"
                                                    class="card-img-top" alt="...">
                                                <div class="card-body">
                                                    <h5 class="card-title">
                                                        {{ $products->find($basket_product->id_product)->name }}</h5>
                                                    <p class="card-text">
                                                        {{ $products->find($basket_product->id_product)->cost }} рублей
                                                    </p>
                                                    <p class="card-text">Количество {{ $basket_product->count }} шт</p>
                                                </div>
                                            </div>
                                        </div>
                                    @endif
                                @endforeach
                            </div>
                            <div class="container">
                                <div>Статус: {{ $basket->status }}</div>
                            </div>
                        </div>
                        <br>
                    @endforeach

                </div>
            </div>
        </div>
    </div>
    <div>
        @include('footer')
    </div>
</body>

</html>
