<header class="d-flex justify-content-between">
    <div class="container-fluid"><a href="{{ route('main') }}"><img src="{{ asset('images/logo.png') }}"></a></div>

    @if (Auth::check())
        <div class="container-fluid"><a href="{{ route('catalog') }}">Каталог</a></div>
        <div class="container-fluid"><a href="{{ route('basket') }}">Корзина</a></div>
        <div class="container-fluid"><a href="{{ route('logout') }}">Выйти</a></div>
    @else
        <div class="container-fluid"><a href="{{ route('authorization') }}">Войти</a></div>
    @endif
</header>
