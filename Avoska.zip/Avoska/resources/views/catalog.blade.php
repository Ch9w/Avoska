<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel='stylesheet' href="{{ asset('css/head.css') }}" />
    <link rel='stylesheet' href="{{ asset('css/main.css') }}" />
    <link rel='stylesheet' href="{{ asset('css/footer.css') }}" />
    <link rel='stylesheet' href="{{ asset('bootstrap/css/bootstrap.min.css') }}" />
</head>

<body>
    <div>
        @include('header')
        <div class='main'>
            <h2 style="text-align: center;">Каталог</h2>
            <div class="container">
                @if ($isadmin)
                    <form class="mb-3" action="addproduct" method="GET">
                        @csrf
                        <input style="width: fit-content;" name="type" type="submit" class="btn btn-secondary bg-primary" value="Добавить товар">
                    </form>
                    <form class="mb-3" action="adminbasket" method="GET">
                        @csrf
                        <input style="width: fit-content;" name="type" type="submit" class="btn btn-secondary bg-primary" value="Контролировать заказы">
                    </form>

                @endif
                <form class="mb-2" method="POST" action="catalog">
                    @csrf
                    <div class="mb-3">Поиск: <input name="poisk" value=""></div>
                    <input type="submit" value="Поиск">
                </form>
            </div>
            <div class="container container-grid">
                @foreach ($products as $product)
                    <div class="col">
                        <div class="card">
                            <img src="{{ asset('images/' . $product->image) }}" class="card-img-top" alt="...">
                            <div class="card-body">
                                <h5 class="card-title">{{ $product->name }}</h5>
                                <p class="card-text">{{ $product->cost }} рублей</p>
                                <form class="mb-1" action="product/{{ $product->id }}" method="GET">
                                    <input type="submit" class="btn btn-secondary bg-primary" value="Перейти">
                                </form>
                                @if ($isadmin)
                                    <form class="mb-1" action="redproduct" method="GET">
                                        @csrf
                                        <input name="idproduct" value="{{ $product->id }}" hidden>
                                        <input name="type" type="submit" class="btn btn-secondary bg-warning"
                                            value="Изменить">
                                    </form>
                                    <form action="catalog" method="POST">
                                        @csrf
                                        <input name="idproduct" value="{{ $product->id }}" hidden>
                                        <input name="type" type="submit" class="btn btn-secondary bg-danger"
                                            value="Удалить">
                                    </form>
                                @endif
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </div>
    <div>
        @include('footer')
    </div>
</body>

</html>
