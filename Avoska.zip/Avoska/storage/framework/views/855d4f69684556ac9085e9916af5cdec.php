<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel='stylesheet' href="<?php echo e(asset('css/head.css')); ?>"/>
    <link rel='stylesheet' href="<?php echo e(asset('css/registration.css')); ?>"/>
    <link rel='stylesheet' href="<?php echo e(asset('css/footer.css')); ?>"/>

</head>
<body>
    <div>
        <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class='reg'>
            <h2 style='text-align:center;'>Регистрация</h2>
            <form method='POST' action='registration'>
                <?php echo csrf_field(); ?>
                <table>
                    <tr>
                        <td>Логин</td>
                        <td>
                            <input type='text' name='login' placeholder='Логин' value="<?php if (isset($_POST['login'])) echo $_POST['login']; ?>">
                        </td>
                    </tr>
                    <tr>
                        <td>email</td>
                        <td><input type='email' name='email' placeholder='email' value="<?php if (isset($_POST['email'])) echo $_POST['email']; ?>"></td>
                    </tr>
                    <tr>
                        <td>Номер телефона</td>
                        <td><input type="tel" pattern="[+]7\s[\(]\d{3}[\)]\s\d{3}[\-]\d{2}[\-]\d{2}" title="Используйте формат: +7 (777) 777-77-77" placeholder="+7 (777) 777-77-77" name='phonenumber' value="<?php if (isset($_POST['phonenumber'])) echo $_POST['phonenumber']; ?>"></td>
                    </tr>
                    <tr>
                        <td>ФИО</td>
                        <td><input type='text' pattern="^[А-Яа-яЁё\s]+$" placeholder='ФИО' title="Используйте только русские символы и пробелы" name='FIO' value="<?php if (isset($_POST['FIO'])) echo $_POST['FIO']; ?>"></td>
                    </tr>
                    <tr>
                        <td>Пароль</td>
                        <td><input type='password' name='password' placeholder='Пароль' value="<?php if (isset($_POST['password'])) echo $_POST['password']; ?>"></td>
                    </tr>
                    <tr>
                        <td>Повторите пароль</td>
                        <td><input type='password' name='repeatpassword' placeholder='Повторите пароль' value="<?php if (isset($_POST['repeatpassword'])) echo $_POST['repeatpassword']; ?>"></td>
                    </tr>
                    <tr>
                        <td colspan='2'><a href="<?php echo e(route('authorization')); ?>">Есть аккаунта?</a></td>
                    </tr>
                    <tr>
                        <td colspan='2'><input type='submit' value='Зарегистрироваться'></td>
                    </tr>
                    <tr>
                        <td colspan='2'>
                            <?php $__errorArgs = ['error'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </td>
                    </tr>


                </table>
            </form>
        </div>
    </div>
    <div>
        <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</body>
</html><?php /**PATH D:\Programs\OSPanel\domains\Avoska\resources\views/registration.blade.php ENDPATH**/ ?>