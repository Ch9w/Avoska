<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel='stylesheet' href="<?php echo e(asset('css/head.css')); ?>" />
    <link rel='stylesheet' href="<?php echo e(asset('css/main.css')); ?>" />
    <link rel='stylesheet' href="<?php echo e(asset('css/footer.css')); ?>" />
    <link rel='stylesheet' href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>" />
</head>

<body>
    <div>
        <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class='main'>
            <h2 style="text-align: center;">Каталог</h2>
            <div class="container">
                <?php if($isadmin): ?>
                    <form class="mb-3" action="addproduct" method="GET">
                        <?php echo csrf_field(); ?>
                        <input style="width: fit-content;" name="type" type="submit" class="btn btn-secondary bg-primary" value="Добавить товар">
                    </form>
                    <form class="mb-3" action="adminbasket" method="GET">
                        <?php echo csrf_field(); ?>
                        <input style="width: fit-content;" name="type" type="submit" class="btn btn-secondary bg-primary" value="Контролировать заказы">
                    </form>

                <?php endif; ?>
                <form class="mb-2" method="POST" action="catalog">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">Поиск: <input name="poisk" value=""></div>
                    <input type="submit" value="Поиск">
                </form>
            </div>
            <div class="container container-grid">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col">
                        <div class="card">
                            <img src="<?php echo e(asset('images/' . $product->image)); ?>" class="card-img-top" alt="...">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo e($product->name); ?></h5>
                                <p class="card-text"><?php echo e($product->cost); ?> рублей</p>
                                <form class="mb-1" action="product/<?php echo e($product->id); ?>" method="GET">
                                    <input type="submit" class="btn btn-secondary bg-primary" value="Перейти">
                                </form>
                                <?php if($isadmin): ?>
                                    <form class="mb-1" action="redproduct" method="GET">
                                        <?php echo csrf_field(); ?>
                                        <input name="idproduct" value="<?php echo e($product->id); ?>" hidden>
                                        <input name="type" type="submit" class="btn btn-secondary bg-warning"
                                            value="Изменить">
                                    </form>
                                    <form action="catalog" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <input name="idproduct" value="<?php echo e($product->id); ?>" hidden>
                                        <input name="type" type="submit" class="btn btn-secondary bg-danger"
                                            value="Удалить">
                                    </form>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <div>
        <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</body>

</html>
<?php /**PATH D:\Programs\OSPanel\domains\Avoska\resources\views/catalog.blade.php ENDPATH**/ ?>