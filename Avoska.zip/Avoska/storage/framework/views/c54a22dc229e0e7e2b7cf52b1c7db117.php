<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel='stylesheet' href="<?php echo e(asset('css/head.css')); ?>" />
    <link rel='stylesheet' href="<?php echo e(asset('css/main.css')); ?>" />
    <link rel='stylesheet' href="<?php echo e(asset('css/footer.css')); ?>" />
    <link rel='stylesheet' href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>" />
</head>

<body>
    <div>
        <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class='main'>
            <div class="container">
                <h2>Добавление товара</h2>
                <form method="POST" action="addproduct" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <table>
                        <tr>
                            <td>Название</td>
                            <td><input type="text" name="name"
                                    value="<?php echo e(old('name')); ?>"></td>
                        </tr>
                        <tr>
                            <td>Цена</td>
                            <td><input type="number" min="1" name="cost" value="<?php echo e(old('cost')); ?>"></td>
                        </tr>
                        <tr>
                            <td>Количество</td>
                            <td><input type="number" min="0" name="count" value="<?php echo e(old('count')); ?>"></td>
                        </tr>
                        <tr>
                            <td>Изображение</td>
                            <td><input name="image" accept="image/png, image/jpg, image/webp" type="file"></td>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div>Поле название обязательно</div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <?php $__errorArgs = ['cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div>Поле цена обязательно</div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <?php $__errorArgs = ['count'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div>Поле количество обязательно</div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div>Загрузите изображение обязательно</div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <?php $__errorArgs = ['error'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <input type="submit" value="Добавить">
                            </td>
                        </tr>
                    </table>
                </form>
            </div>
        </div>
    </div>
    <div>
        <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</body>

</html>
<?php /**PATH D:\Programs\OSPanel\domains\Avoska\resources\views/addproduct.blade.php ENDPATH**/ ?>