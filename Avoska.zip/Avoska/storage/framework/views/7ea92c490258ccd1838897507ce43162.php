<footer class="d-flex">
    <div class="footer-1">
        <a href='#'>Политика конфиденциальности</a>
    </div>
    <div class="footer-2">
        <a href='#'>Пользовательское соглашение</a>
    </div>
</footer><?php /**PATH C:\OSPanel\domains\lomov\Avoska\resources\views/footer.blade.php ENDPATH**/ ?>