<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel='stylesheet' href="<?php echo e(asset('css/head.css')); ?>" />
    <link rel='stylesheet' href="<?php echo e(asset('css/main.css')); ?>" />
    <link rel='stylesheet' href="<?php echo e(asset('css/footer.css')); ?>" />
    <link rel='stylesheet' href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>" />
</head>

<body>
    <div>
        <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class='main'>
            <div class="container">
                <h3>Текущая корзина</h3>
                <?php $__errorArgs = ['error'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="container row row-cols-2 row-cols-md-4 w-100">
                    <?php $__currentLoopData = $basket_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $basket_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col mb-4">
                            <div class="card">
                                <img src="<?php echo e(asset('images/' . $products->find($basket_product->id_product)->image)); ?>"
                                    class="card-img-top" alt="...">
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo e($products->find($basket_product->id_product)->name); ?></h5>
                                    <p class="card-text"><?php echo e($products->find($basket_product->id_product)->cost); ?> рублей
                                    </p>
                                    <p class="card-text">Количество <?php echo e($basket_product->count); ?> шт</p>
                                    <form action="basket" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <input name="idproduct" value="<?php echo e($basket_product->id); ?>" hidden>
                                        <input class="w-100" name="thiscount" type="number" min="1"
                                            value="1">
                                        <br> <br>

                                        <input name="type" type="submit" class="btn bg-warning" value="Изменить">
                                    </form>
                                    <br>
                                    <form action="basket" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <input name="idproduct" value="<?php echo e($basket_product->id); ?>" hidden>
                                        <input name="type" type="submit" class="btn bg-danger" value="Удалить">
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div>
                    <h3>Оформление заказа</h3><br>
                    <?php $__errorArgs = ['error1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message); ?>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <form class="s-20" action="basket" method="POST">
                        <?php echo csrf_field(); ?>
                        <div>Адрес: <input name="address" type="text"></div>
                        <input name="type" type="submit" value="Заказать">
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div>
        <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</body>

</html>
<?php /**PATH C:\OSPanel\domains\lomov\Avoska\resources\views/basket.blade.php ENDPATH**/ ?>