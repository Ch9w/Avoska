<header class="d-flex justify-content-between">
    <div class="container-fluid"><a href="<?php echo e(route('main')); ?>"><img src="<?php echo e(asset('images/logo.png')); ?>"></a></div>

    <?php if(Auth::check()): ?>
        <div class="container-fluid"><a href="<?php echo e(route('catalog')); ?>">Каталог</a></div>
        <div class="container-fluid"><a href="<?php echo e(route('basket')); ?>">Корзина</a></div>
        <div class="container-fluid"><a href="<?php echo e(route('logout')); ?>">Выйти</a></div>
    <?php else: ?>
        <div class="container-fluid"><a href="<?php echo e(route('authorization')); ?>">Войти</a></div>
    <?php endif; ?>
</header>
<?php /**PATH D:\Programs\OSPanel\domains\Avoska\resources\views/header.blade.php ENDPATH**/ ?>