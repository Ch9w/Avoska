<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel='stylesheet' href="<?php echo e(asset('css/head.css')); ?>" />
    <link rel='stylesheet' href="<?php echo e(asset('css/main.css')); ?>" />
    <link rel='stylesheet' href="<?php echo e(asset('css/footer.css')); ?>" />
    <link rel='stylesheet' href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>" />
</head>

<body>
    <div>
        <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class='main'>
            <h2 style="text-align: center;">Товар</h2>
            <div class="container">
                <h1><?php echo e($product->name); ?></h1>
                <div class="container d-flex">
                    <div class="w-50">
                        <img src="<?php echo e(asset('images/' . $product->image)); ?>" class="w-100" alt="...">
                    </div>
                    <div class="w-50 cost p-4">
                        <div>Цена: <?php echo e($product->cost); ?> рублей</div>
                        <?php if(Auth::check()): ?>
                            <?php if($product->count > 0): ?>
                                <div>
                                    <form action="<?php echo e($product->id); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <div>
                                            <input type="number" min="1" value="1" name="count" value="<?php if (isset($_POST['count'])) echo $_POST['count']; ?>">
                                        </div>
                                        <br>
                                        <div>
                                            <input type="submit" class="btn btn-secondary bg-primary" value="Добавить">
                                        </div>
                                    </form>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>
                        <?php $__errorArgs = ['error'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div>
        <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</body>

</html>
<?php /**PATH C:\OSPanel\domains\lomov\Avoska\resources\views/product.blade.php ENDPATH**/ ?>