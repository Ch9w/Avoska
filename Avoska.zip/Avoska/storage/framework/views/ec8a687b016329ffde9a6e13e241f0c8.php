<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel='stylesheet' href="<?php echo e(asset('css/head.css')); ?>" />
    <link rel='stylesheet' href="<?php echo e(asset('css/main.css')); ?>" />
    <link rel='stylesheet' href="<?php echo e(asset('css/footer.css')); ?>" />
    <link rel='stylesheet' href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>" />
</head>

<body>
    <div>
        <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class='main'>
            <h2 style="text-align: center;">Каталог</h2>
            <div class="container">
                <form method="POST" action="catalog">
                    <?php echo csrf_field(); ?>
                    <div>Поиск: <input name="poisk" value=""></div>
                    <input type="submit" value="Поиск">
                </form>
            </div>
            <div class="container row row-cols-2 row-cols-md-4">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <form action="product/<?php echo e($product->id); ?>" method="GET">
                        <div class="col mb-4">
                            <div class="card">
                                <img src="<?php echo e(asset('images/' . $product->image)); ?>" class="card-img-top" alt="...">
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo e($product->name); ?></h5>
                                    <p class="card-text"><?php echo e($product->cost); ?> рублей</p>
                                    <input type="submit" class="btn btn-secondary bg-primary" value="Перейти">
                                </div>
                            </div>
                        </div>
                    </form>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <div>
        <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</body>

</html>
<?php /**PATH C:\OSPanel\domains\lomov\Avoska\resources\views/catalog.blade.php ENDPATH**/ ?>